/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cajero;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Stack;

/**
 *
 * @author fband
 */
public class historialTransacciones {
    String cuenta1;
    String cuenta2;
    double deposito;
    
     //----------------------------------------------
    String dir = "C:\\Users\\fband\\Downloads\\cajero (1)\\cajero\\registro\\registros.txt";
    //----------------------------------------------
    
   public historialTransacciones(String cuenta1,String cuenta2,double deposito){
       this.cuenta1 = cuenta1;
       this.cuenta2 = cuenta2;
       this.deposito=deposito;
   }
    
    public static String findMatchingLines(String filePath, String prefix) {
       Stack<String> stack = new Stack<>();
        StringBuilder result = new StringBuilder();
        int count = 0;
        String prefixWithColon = prefix + ": ";

        // Primero leemos el archivo y guardamos las líneas en un stack
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stack.push(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Ahora leemos desde el stack (que nos da las líneas de abajo hacia arriba)
        while (!stack.isEmpty() && count < 10) {
            String line = stack.pop();
            if (line.startsWith(prefixWithColon)) {
                // Guardamos toda la línea que coincide con el prefijo
                result.append(line).append("\n");
                count++;
            }
        }

        return result.toString();
    }
    public static LocalDate obtenerFechaActual() {
        
        return LocalDate.now();
    }
     public static String getCurrentTimeWithIntegerSeconds() {
        // Obtén la hora actual
        LocalDateTime now = LocalDateTime.now();
        
        // Formatea la hora actual a una cadena, incluyendo segundos como enteros
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return now.format(formatter);
    }
     public static void agregarLinea(String filePath, String nuevaLinea) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(nuevaLinea);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     public void guardarDeposito(){
         LocalDate fechaActual = LocalDate.now();
        // Convertir la fecha actual a String
        String fechaString = fechaActual.toString();

        // Obtener la hora actual
       
        // Convertir la hora actual a String
       String currentTime = getCurrentTimeWithIntegerSeconds();
        String hist = cuenta1+": "+fechaString+" "+currentTime+" "+"SE DEPOSITO: "+deposito+" A LA CUENTA: "+cuenta2;
        agregarLinea(dir,hist);
     }
    
     
     public void guardarIngreso(){
         LocalDate fechaActual = LocalDate.now();
        // Convertir la fecha actual a String
        String fechaString = fechaActual.toString();

        // Obtener la hora actual
       
        // Convertir la hora actual a String
       String currentTime = getCurrentTimeWithIntegerSeconds();
        String hist = cuenta2+": "+fechaString+" "+currentTime+" "+"LA CUENTA: "+cuenta1+" TE DEPOSITO: "+deposito;
        agregarLinea(dir,hist);
     }
     
    
}
